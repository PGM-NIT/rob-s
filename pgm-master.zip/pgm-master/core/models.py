# from django.db import models
# from django.contrib.auth.models import User
# from django.core.files.storage import FileSystemStorage
# from django.conf import settings
# import os
#
# class Unidade(models.Model):
#
#     unidade = models.CharField(max_length=255, unique=True)
#
#     def __str__(self):
#         return self.unidade
#
#
# class Objeto(models.Model):
#
#     unidade = models.ForeignKey(Unidade, on_delete=models.CASCADE)
#     objeto = models.CharField(max_length=255)
#
#     class Meta:
#         unique_together = ["unidade", "objeto"]
#
#     def __str__(self):
#         return '%s - %s' % (self.unidade, self.objeto)
#
#
# class ComplementoObjeto(models.Model):
#
#     unidade = models.ForeignKey(Unidade, on_delete=models.CASCADE)
#     objeto = models.ForeignKey(Objeto, on_delete=models.CASCADE)
#     complementoobjeto = models.CharField(max_length=255)
#
#     class Meta:
#         unique_together = ["unidade", "objeto", "complementoobjeto"]
#
#     def __str__(self):
#         return '%s - %s' % (self.objeto, self.complementoobjeto)
#
#
#
#
# class Informacoes(models.Model):
#
#     nuprocessounificadoformatado = models.CharField(max_length=50, unique=True, default=False)
#     data_inicial = models.DateField(blank=True, null=True)
#     moeda = models.CharField(max_length=20, blank=True, null=True)
#     valor_acao_float = models.FloatField(blank=True, null=True)
#     vara = models.CharField(max_length=300, blank=True, null=True)
#     juiz = models.CharField(max_length=300, blank=True, null=True)
#     area = models.CharField(max_length=50, blank=True, null=True)
#     classe = models.CharField(max_length=300, blank=True, null=True)
#     assunto = models.CharField(max_length=300, blank=True, null=True)
#     outros_assuntos = models.CharField(max_length=2000, blank=True, null=True)
#     tramitacao_prioritaria = models.CharField(max_length=50, blank=True, null=True)
#     incidente_ou_execucao = models.CharField(max_length=400, blank=True, null=True)
#     extinto_suspenso = models.CharField(max_length=50, blank=True, null=True)
#     processo = models.CharField(max_length=100, blank=True, null=True)
#     processo_principal = models.CharField(max_length=300, blank=True, null=True)
#     outros_numeros = models.TextField(blank=True, null=True)
#     apensado_ao = models.CharField(max_length=300, blank=True, null=True)
#     entranhado_ao = models.CharField(max_length=1000, blank=True, null=True)
#     unificado_ao = models.CharField(max_length=100, blank=True, null=True)
#     distribuicao = models.CharField(max_length=100, blank=True, null=True)
#     recebido_em = models.CharField(max_length=100, blank=True, null=True)
#     controle = models.CharField(max_length=30, blank=True, null=True)
#     cdas = models.CharField(max_length=300, blank=True, null=True)
#     dados_da_precatoria = models.CharField(max_length=300, blank=True, null=True)
#     local_fisico = models.CharField(max_length=1000, blank=True, null=True)
#     recurso = models.CharField(max_length=300, blank=True, null=True)
#     acao_incidental = models.CharField(max_length=300, blank=True, null=True)
#     peticao_diversa = models.CharField(max_length=300, blank=True, null=True)
#     segredo_de_justica = models.BooleanField(default=False)
#     digital = models.BooleanField(default=False)
#
#     parent = models.ForeignKey('self', null=True, blank=True, related_name='children', on_delete=models.SET_NULL)
# #
#     sei = models.CharField(blank=True, null=True, max_length=255)
#
#     unidade = models.ManyToManyField(Unidade)
#     objeto = models.ManyToManyField(Objeto)
#     complementoobjeto = models.ManyToManyField(ComplementoObjeto)
#
#     data_abertura_entrada = models.DateField(auto_now=True)
#     data_ult_atualizacao = models.DateField(auto_now_add=True, blank=True)
#     versao_parser = models.FloatField()
#
#     def __str__(self):
#         return self.nuprocessounificadoformatado
#
#
# class Partes(models.Model):
#     nome = models.CharField(max_length=2000)
#     posicao = models.CharField(max_length=2000)
#     procuradores = models.TextField(null=True, blank=True)
#
#     informacao = models.ForeignKey(Informacoes, on_delete=models.CASCADE)
#
#     def __str__(self):
#         return self.nome
#
#     class Meta:
#         ordering = ('posicao',)
#
#
# class Documentos(models.Model):
#
#     informacao = models.ForeignKey(Informacoes, on_delete=models.CASCADE)
#     indicepagina = models.IntegerField(null=True)
#     title = models.CharField(max_length=300, null=True)
#     cddocumento = models.IntegerField()
#     dtinclusao = models.DateTimeField(null=True)
#     cdtipodocdigital = models.IntegerField(null=True)
#     parametros = models.CharField(max_length=1000, null=True)
#     link_doc = models.CharField(max_length=1000, null=True)
#     conteudo = models.TextField(null=True)
#
#
#     def __str__(self):
#         return '%s - %s' % (self.informacao, self.indicepagina)
#
#     class Meta:
#         unique_together = ['informacao', 'indicepagina', 'title']
#
#
# class Mandados(models.Model):
#
#     informacao = models.ForeignKey(Informacoes, on_delete=models.CASCADE, null=True, blank=True)
#     indicepagina = models.IntegerField()
#     codigo_validacao = models.CharField(max_length=200, null=True)
#     url = models.TextField()
#
#     parte_citada = models.ForeignKey(Partes, on_delete=models.PROTECT, related_name='p_citada', null=True, blank=True)
#     parte_oposta = models.ForeignKey(Partes, on_delete=models.PROTECT, related_name='p_oposta', null=True, blank=True)
#     unidade = models.ForeignKey(Unidade, on_delete=models.PROTECT, null=True, blank=True)
#     datahora_recebimento = models.DateTimeField(null=True)
#
#     usuario_recebimento = models.ForeignKey(User, on_delete=models.PROTECT, null=True, blank=True)
#
#     sei_gerado = models.CharField(max_length=255, null=True)
#
#     data_recebimento = models.DateTimeField(null=True)
#     urgente = models.BooleanField(default=False)
#
#
# class Movimentacoes(models.Model):
#
#     informacao = models.ForeignKey(Informacoes, on_delete=models.CASCADE)
#     ordem = models.IntegerField()
#     data = models.DateField()
#     link = models.CharField(max_length=200, null=True)
#     tag = models.CharField(max_length=200)
#     descricao = models.TextField(null=True)
#
#     def __str__(self):
#         return '%s - %s' % (self.informacao, self.ordem)
#
#     class Meta:
#         ordering = ('ordem',)
#         unique_together = ['informacao', 'ordem']
#
#
#
# ModelosPeticoesStorage = FileSystemStorage(location=os.path.join(settings.BASE_DIR, 'arquivos', 'modelospeticoes'))
#
# class ModelosPeticoes(models.Model):
#
#     unidade = models.ForeignKey(Unidade, on_delete=models.CASCADE)
#     objeto = models.ForeignKey(Objeto, on_delete=models.CASCADE, null=True)
#     complementoobjeto = models.ForeignKey(ComplementoObjeto, on_delete=models.CASCADE)
#     modelonome = models.CharField(max_length=255, unique=True)
#     modeloarquivo = models.FileField(storage=ModelosPeticoesStorage)
#
#     class Meta:
#         managed = True
#
#     def __str__(self):
#         return self.modelonome
