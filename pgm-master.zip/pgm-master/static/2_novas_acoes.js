
var csrfmiddlewaretoken =  $( "input[name*='csrfmiddlewaretoken']" ).attr('value')


function get_tjsp(){

  var cnj_usuario = $("#cnj").val();

  if (cnj_usuario.length == 25){
      $( "#cnj" ).prop( "disabled", true );
      $( "#botao_cnj" ).prop( "disabled", true );
      var params = {"origem" : "cnj_usuario",
                    "cnj_usuario": cnj_usuario,
                    "csrfmiddlewaretoken" : csrfmiddlewaretoken};
      console.log('click');
      $("#frame_grid_intimacao").load('novas_acoes', params);

  }

}

function criar_processo() {

  $( "#botao_criar_processo" ).prop( "disabled", true );
  var payload = {"origem" : "criar_processo",
                 "intimacao" : $("#codigo_de_validacao").val(),
                 "parte_contraria" : $("#parte_contraria").val(),
                 "parte_citada" : $("#parte_citada").val(),
                 "unidade" : $("#unidade").val(),
                 "csrfmiddlewaretoken" : csrfmiddlewaretoken};

  $("#resultado").load('novas_acoes', payload);
}

$(document).on("click", "#botao_cnj", get_tjsp)
$(document).on("click", "#botao_criar_processo", criar_processo)
