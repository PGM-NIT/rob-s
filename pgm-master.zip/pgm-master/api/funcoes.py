from bs4 import BeautifulSoup as bs
import datetime
import re
import json
from unidecode import unidecode
import io
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
from .models import *
from django.conf import settings
import os
import textract
import tempfile
import time
import requests
from seleniumrequests import Chrome

def get_siajd_looged_session():
    s = requests.session()
    url_login = 'https://siajd.pgm.prefeitura.sp.gov.br/UC_AUT_001_AutenticarUsuario/Login'

    data = {'Usuario': 'D858414',
            'Senha': '013452Ab',
            'TextoCaptcha': ''}

    s.post(url_login, data=data)

    return s


def get_siajd(s, cnj):

    url = 'https://siajd.pgm.prefeitura.sp.gov.br/UC_ACA_024_ConsultarAutos/Pesquisar'
    params = {'NumeroAutos': cnj}

    r = s.get(url, params=params, allow_redirects=True)
    sp = bs(r.content, 'html5lib')

    return {unidecode(i.get('title').lower().strip()).replace(' ', '_'): i.get('value') for i in sp.findAll(attrs={'class':'form-control'})}


def get_info_siajd(cnj):

    s = requests.session()
    url_login = 'https://siajd.pgm.prefeitura.sp.gov.br/UC_AUT_001_AutenticarUsuario/Login'

    data = {'Usuario': 'D858414',
            'Senha': '013452Ab',
            'TextoCaptcha': ''}

    s.post(url_login, data=data)

    url = 'https://siajd.pgm.prefeitura.sp.gov.br/UC_ACA_024_ConsultarAutos/Pesquisar'
    params = {'NumeroAutos': cnj}

    r = s.get(url, params=params, allow_redirects=True)
    sp = bs(r.content, 'html5lib')

    return {unidecode(i.get('title').lower().strip()).replace(' ', '_'): i.get('value') for i in sp.findAll(attrs={'class':'form-control'})}


def get_tjsp(nuprocessounificadoformatado, documentos=False, driver=False):


    crit_assinatura = re.compile('Este documento é cópia do original.*? e código .{,8}\.',re.DOTALL)


    entrada = {'nuprocessounificadoformatado' : nuprocessounificadoformatado,
               'versao_parser': 5.1}

    encerrar = False
    if not driver:
        driver = Chrome(os.path.join(settings.STATICFILES_DIRS[0], 'chromedriver'))
        driver.get('http://esaj.tjsp.jus.br/sajcas/login?usuarioIntegracao=46392072000122&senhaIntegracao=sn1305sefd')
        encerrar = True


    driver.get(f'https://esaj.tjsp.jus.br/cpopg/search.do?cbPesquisa=NUMPROC&dadosConsulta.tipoNuProcesso=UNIFICADO&dadosConsulta.valorConsultaNuUnificado={nuprocessounificadoformatado}')
    sp = bs(driver.page_source, 'html5lib')

    if "mostrar: 'true'" in str(sp):
        entrada['segredo_de_justica'] = True

    else:
        if sp.find('a', attrs={'title': 'Pasta digital'}) is not None or sp.find('a', attrs={'class': 'linkConsultaSG'}) is not None:

            entrada['digital'] = True

            crit = re.compile(r'requestScope = (.*?);\s+?var', re.I | re.DOTALL)
            parametro = re.search(r'.codigo=(.*?)&', driver.current_url).group(1)



            driver.get(f'https://esaj.tjsp.jus.br/cpopg/abrirPastaDigital.do?processo.codigo={parametro}')

            j = json.loads(re.search(crit, driver.page_source).group(1))

            coleta = []
            c_assinatura = re.compile(
                'p\s{,4}a\s{,4}r\s{,4}a\s{,4}c\s{,4}o\s{,4}n\s{,4}f\s{,4}e\s{,4}r\s{,4}i\s{,4}r\s{,4}.*?fls.{,4}\d+',
                re.I | re.DOTALL)

            for linha in j:
                for sublinha in linha['children']:

                    rp = {
                        'indicepagina': sublinha['data']['indicePagina'],
                        'title': linha['data']['title'],
                        'cddocumento': linha['data']['cdDocumento'],
                        'dtinclusao': linha['data']['dtInclusao'],
                        'cdtipodocdigital': linha['data']['cdTipoDocDigital'],
                        'parametros': sublinha['data']['parametros'].replace('amp;', ''),
                    }

                    if documentos:

                        r_doc = s.get('https://esaj.tjsp.jus.br/pastadigital/getPDF.do?' + rp['parametros'], verify=False)
                        rp['link_doc'] = r_doc.url

                        tempdoc = tempfile.NamedTemporaryFile(suffix='.pdf', delete=False )
                        with open(tempdoc.name, 'wb') as f:
                            f.write(r_doc.content)
                        t = textract.process(tempdoc.name, encoding='latin1').decode('latin1')
                        t = re.sub(crit_assinatura, '', t).strip()

                        if len(t) > 100:
                            t = t.encode(encoding='latin1', errors='replace').decode(encoding='latin1')
                            rp['conteudo'] = t

                        os.remove(tempdoc.name)

                    coleta += [rp]

            if len(coleta) > 0:
                entrada['documentos'] = coleta


        # diversos

        for item in sp.findAll(attrs={'class': 'labelClass', 'style': 'text-align:right;font-weight:bold;;'}):
            if item.get('for') == 'tag.dados.rotulo.principal':
                entrada['Processo principal'] = item.findNext(attrs={'class': 'processoPrinc'}).get_text()

            elif item.get_text() == 'Distribuição:':
                entrada[item.get_text().strip().replace(':', '')] = item.findNext('span').get_text().strip()

                rp = item.findNext('span').findNext()
                if rp.find('span') is not None:
                    entrada['vara'] = rp.find('span').get_text().strip()

            elif item.get_text() == 'Apensado ao:':
                entrada[item.get_text().strip().replace(':', '')] = item.findNext(
                    attrs={'class': 'processoPaiApenso'}).get_text().strip()

            elif item.get_text() in ['Incidente:', 'Execução de Sentença:']:
                entrada['incidente_ou_execucao'] = item.findNext('span').get_text().strip()
            else:
                entrada[item.get_text().strip().replace(':', '')] = item.findNext('span').get_text().strip()

            if item.get_text() == 'Recebido em:':
                entrada['vara'] = item.findNext('span').findNext('span').get_text()

        for i in sp.findAll('span', attrs={'class': 'labelClass'}):
            entrada[i.get_text().replace(':', '')] = i.next.next.strip()

        # extinto_suspenso
        if sp.find('span', attrs={'style': 'color: red; padding-left: 6px;'}) is not None:
            entrada['extinto_suspenso'] = sp.find('span', attrs={'style': 'color: red; padding-left: 6px;'}).get_text()

        if 'Distribuição' in entrada.keys():

            entrada['data_inicial'] = entrada['Distribuição'][:10]
        elif 'Recebido em' in entrada.keys():
            entrada['data_inicial'] = entrada['Recebido em'][:10]

        if sp.find('span', attrs={'style': 'color: #FF0000;'}) is not None:
            entrada['tramitacao_prioritaria'] = 'Tramitação prioritária'
        if 'Valor da ação' in entrada.keys():
            entrada['Valor da ação'] = re.sub(r'\s\s+', ' ', entrada['Valor da ação'])
            if re.match(r'(.*?)\s', entrada['Valor da ação']) is not None:
                entrada['moeda'] = re.match(r'(.*?)\s', entrada['Valor da ação']).group(1)
            if re.search(r'\s(.*)', entrada['Valor da ação']) is not None:
                rp = re.search(r'\s(.*)', entrada['Valor da ação']).group(1).strip()
                entrada['valor_acao_float'] = float(rp.replace('.', '').replace(',', '.'))

            del entrada['Valor da ação']

        # partes
        coleta = []
        controle = []

        for item in sp.findAll('td', attrs={'align': 'right', 'width': '141', 'valign': 'top','style': 'padding-bottom: 5px'}):
            rp = {}
            if item.findNext('td').next.strip() not in controle:
                controle += [item.findNext('td').next.strip()]
                rp['nome'] = item.findNext('td').next.strip()
                rp['posicao'] = item.get_text().strip().replace(':', '')

                procuradores = []

                for subitem in item.findNextSibling().findAll('span'):
                    classe = subitem.get_text().replace(':', '').strip()
                    nome = subitem.next.next.strip()
                    procuradores += [[classe, nome]]

                classes = list(set([i[0] for i in procuradores]))
                subcoleta = {}

                for classe in classes:
                    nome_procurador = [i[1] for i in procuradores if i[0] == classe]
                    subcoleta[classe] = nome_procurador

                if len(subcoleta) > 0:
                    rp['procuradores'] = subcoleta
                coleta += [rp]

        if len(coleta) > 0:
            entrada['partes'] = coleta

        # movimentacoes
        coleta = []
        lista = sp.findAll('td', attrs={'width': '120', 'style': 'vertical-align: top'})
        r = list(range(len(lista) - 1, -1, -1))

        for n, item in enumerate(sp.findAll('td', attrs={'width': '120', 'style': 'vertical-align: top'})[::-1]):

            mov = {'ordem': n,
                   'data': item.get_text().strip()}

            if len(item.findNext('td').findChildren()) > 0:
                mov['link'] = item.findNext('td').findNext('td').findChild('a').get('id')
                mov['tag'] = item.findNext('td').findNext('td').findChild('a').get_text().strip()
            else:

                mov['tag'] = item.findNext('td').findNext('td').next.strip()
                mov['descricao'] = item.findNext('td').findNext('td').findChild('span').get_text().strip()
            coleta += [mov]

        if len(coleta) > 0:
            entrada['movimentacoes'] = coleta

    entrada = {unidecode(k.lower()).strip().replace(' ', '_'): v for k, v in entrada.items() if v}

    # formatacoes e salvar

    if 'data_inicial' in entrada.keys():

        entrada['data_inicial'] = datetime.datetime.strptime(entrada['data_inicial'], '%d/%m/%Y').date()

    informacao = Informacoes(**{k: v for k, v in entrada.items() if k not in ['movimentacoes', 'partes', 'documentos']})
    informacao.save()

    if 'documentos' in entrada.keys():
        entrada['documentos'] = [{k: (v if k !=  'dtinclusao' else datetime.datetime.strptime(v, '%d/%m/%Y %H:%M:%S')) for k,v in i.items() } for i in entrada['documentos'] ]

        lista = [Documentos(**i, informacao=informacao) for i in entrada['documentos']]

        try:
            Documentos.objects.bulk_create(lista)
        except:
            for c in lista:
                try:
                    c.save()
                except:
                    pass

    # aciona o get dados para pegar cpf e cnpj
    cnj = (nuprocessounificadoformatado[:7] +
           '-' +
           nuprocessounificadoformatado[7:9] +
           '.' +
           nuprocessounificadoformatado[9:13] +
           '.' + nuprocessounificadoformatado[13] +
           '.' +
           nuprocessounificadoformatado[14:16] +
           '.' +
           nuprocessounificadoformatado[16:])

    s = requests.session()
    url_login = 'https://siajd.pgm.prefeitura.sp.gov.br/UC_AUT_001_AutenticarUsuario/Login'

    data = {'Usuario': 'D858414',
            'Senha': '013451Ab',
            'TextoCaptcha': ''}

    s.post(url_login, data=data)
    url = 'https://siajd.pgm.prefeitura.sp.gov.br/UC_ACA_017_ManterAcaoJudicial/ImportarDadosTJ'
    params = {'NrAutos': cnj}

    r = s.post(url, json=params, allow_redirects=True)
    j = r.json()


    if 'Erro' in j.keys():
        pass

    else:
        cpfcnpjpartes = {i['Parte'] : i['CPFCNPJ'] for i in j['ListaPartes']}
        if 'partes' in entrada.keys():
            for e in entrada['partes']:
                e['cpfcnpj'] = cpfcnpjpartes[e['nome']]

    if 'partes' in entrada.keys():

        lista = [Partes(**i, informacao=informacao) for i in entrada['partes']]
        Partes.objects.bulk_create(lista)

    if 'movimentacoes' in entrada.keys():
        entrada['movimentacoes'] = [{k: (v if k !=  'data' else datetime.datetime.strptime(v, '%d/%m/%Y').date()) for k,v in i.items() } for i in entrada['movimentacoes'] ]
        lista = [Movimentacoes(**i, informacao=informacao) for i in entrada['movimentacoes']]
        Movimentacoes.objects.bulk_create(lista)

    if encerrar:
        driver.close()

    return informacao
