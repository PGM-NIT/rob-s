from django.urls import path

from . import views

urlpatterns = [
    path('consulta_processo', views.consulta_processo, name='consulta_processo'),
    path('cadastro_modelo', views.cadastro_modelo, name='cadastro_modelo'),
    path('forma_modelo', views.forma_modelo, name='forma_modelo'),
]
