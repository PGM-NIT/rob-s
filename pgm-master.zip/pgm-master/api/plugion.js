//
// # edita a tela de cadastro
//
// $('#txtInfoAux1_DadosGerais').parent().detach().appendTo( $('#txtAutos_DadosGerais').parent());
//
// $('#txtInfoAux1_DadosGerais').removeAttr('disabled');
//
// $("label[for='txtInfoAux1']").text('senha do processo');

#
    <form action="datadestination.php" method="POST" target="_blank" id="myform">
      <input type="hidden" name="list" id="list-data"/>
      <input type="submit" value="Submit">
    </form>
