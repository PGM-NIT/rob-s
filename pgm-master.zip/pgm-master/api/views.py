from django.shortcuts import render
from rest_framework.decorators import api_view
from django.http import HttpResponse
import re
from django.contrib.auth.decorators import login_required
import datetime
from django.http import JsonResponse, FileResponse
import json
import io
from docx import Document

from django.views.decorators.csrf import csrf_exempt

from .funcoes import *
from .models import *

from django.http import FileResponse


# Create your views here.

@csrf_exempt
@api_view(['POST'])
def consulta_processo(request):

    params = request.POST.dict()
    nuprocessounificadoformatado = params['nuprocessounificadoformatado']
    nuprocessounificadoformatado = re.sub('[^0-9]','', nuprocessounificadoformatado)

    if Informacoes.objects.filter(nuprocessounificadoformatado=nuprocessounificadoformatado).exists():
        x = Informacoes.objects.get(nuprocessounificadoformatado=nuprocessounificadoformatado)
        print(x)
        return HttpResponse('oi')

    else:
        informacao = get_tjsp(nuprocessounificadoformatado=nuprocessounificadoformatado)

        return HttpResponse('ola')

@csrf_exempt
def cadastro_modelo(request):

    if request.method == 'GET':

        unidades = Unidade.objects.all().values()
        objetos = Objeto.objects.all().values()
        complementoobjetos = ComplementoObjeto.objects.all().values()

        nomesexistentes_p = [(i.unidade_id, i.nome.lower()) for i in Modelos.objects.all().only('nome', 'unidade_id')]
        nomesexistentes = {k:[] for k in set([i[0] for i in nomesexistentes_p])}
        for k, v in nomesexistentes_p:
            nomesexistentes[k].append(v)
        nomesexistentes = json.dumps(nomesexistentes)



        context = {'unidades': unidades,
                   'objetos': objetos,
                   'complementoobjetos': complementoobjetos,
                   'nomesexistentes': nomesexistentes}

        return render(request, 'api/cadastro_modelo.html', context=context)

    else:

        params = request.POST.dict()

        print(params)

        if params['origem'] == 'verifica_modelo':

            if Modelos.objects.filter(unidade=params['unidade'], nome=params['nome_do_modelo']).exists():
                return "true"
            else:
                return "false"

        elif params['origem'] == 'cadastro_modelo':

            file_params = request.FILES

            bytes = file_params['arquivo'].read()
            nome = params['nome_do_modelo']
            unidade = Unidade.objects.get(id=params['unidade'])
            modelo = Modelos(bytes=bytes, nome=nome, unidade=unidade)

            modelo.save()

            buffer = io.BytesIO(bytes)
            doc = Document(buffer)
            texto = ' '.join([i.text for i in doc.paragraphs])

            criterios = list(set([i.strip() for i in re.findall('\{(.*?)\}', texto)]))

            for c in criterios:
                crit = ModelosCriteiros(modelo=modelo, chave=c)
                crit.save()

            return HttpResponse(modelo.id)

@csrf_exempt
def forma_modelo(request):

    campos_siajd = ['ndeg_dos_autos', 'procurador_responsavel',
                    'unidade', 'vara', 'objeto', 'classe_cnj', 'complemento_do_objeto', 'assunto_cnj',
                    'numero_pa', 'numero_sei', 'autor_principal', 'possui_oc_nao_revisada',
                    'reu_principal', 'observacao']

    if request.method == 'GET':

        cnj = request.GET['cnj']

        dados_siajd = get_info_siajd(cnj)

        dados_siajd = {('cnj' if k == 'ndeg_dos_autos_unificado' else k):v for k,v in dados_siajd.items()}
        unidade = Unidade.objects.get(nome=dados_siajd['unidade'])

        modelos = Modelos.objects.filter(unidade=unidade).only('id')
        modeloscriterios = ModelosCriteiros.objects.filter(modelo__in=modelos).values()
        modelos = modelos.values('id', 'nome',  'objeto_id', 'complementoobjeto_id', 'etapa_id',)
        modelos = [{k: (v if v else 0) for k,v in x.items()} for x in modelos]
        chaves = json.dumps({k:[v['chave'] for v in modeloscriterios if v['modelo_id'] == k] for k in set([i['id'] for i in modelos])})

        objetos = Objeto.objects.filter(unidade=unidade)
        complementoobjetos = ComplementoObjeto.objects.filter(objeto__in=objetos)
        etapas = Etapa.objects.all()

        campos = set([i['chave'] for i in modeloscriterios])
        campos.add('cnj')

        campos = {k: (dados_siajd[k] if k in dados_siajd.keys() else '') for k in campos }
        campos = [{'chave':k, 'valor':v} for k,v in campos.items()]

        context = {'modelos': modelos,
                   'cnj': cnj,
                   'objetos': objetos.values(),
                   'complementoobjetos' : complementoobjetos.values(),
                   'etapas':etapas.values(),
                   'chaves' : chaves,
                   'campos' : campos
                   }

        return render(request, 'api/forma_modelo_00.html', context=context)

    else:

        modelo = request.POST.dict()['modelo']
        modelo = Modelos.objects.get(pk=modelo)

        chaves = ModelosCriteiros.objects.filter(modelo=modelo).values('chave')
        chaves = [i['chave'] for i in chaves]
        chaves = {k:v  for k,v in request.POST.dict().items() if k in chaves}

        print(chaves)

        buffer = io.BytesIO(modelo.bytes)
        doc = Document(buffer)

        coleta = []
        coletar = False

        for paragrafo in doc.paragraphs:
            for run in paragrafo.runs:
                if '{' in run.text:
                    coletar = True
                    coleta.append(run)

                elif coletar:
                    coleta.append(run)

                if '}' in run.text:

                    coletar = False
                    key = ''.join([i.text for i in coleta])

                    key = re.search('{(.*)}', key).group(1).strip()

                    if '}' in coleta[0].text:
                        coleta[0].text = re.sub('{.*?}',chaves[key].upper(), coleta[0].text)
                    else:
                        coleta[0].text = re.sub('{.*',chaves[key].upper(), coleta[0].text)

                    for remover in coleta[1:]:
                        remover.clear()

                    coleta = []

        response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.wordprocessingml.document')
        response['Content-Disposition'] = 'attachment; filename=download.docx'
        doc.save(response)

        return response



@csrf_exempt
def teste(request):
    return render(request, 'api/forma_modelo.html', context={})
