

var funcA = function() {
var myImage = document.getElementById('text_captchaimg');
var myCanvas = document.createElement('canvas');
var ctx = myCanvas.getContext('2d');
ctx.drawImage(myImage, 0, 0);
var mydataURL=myCanvas.toDataURL('image/jpg');

heroku create --buildpack https://github.com/paulfurley/heroku-buildpack-python-opencv-3.1.0.git -a pgmsp
