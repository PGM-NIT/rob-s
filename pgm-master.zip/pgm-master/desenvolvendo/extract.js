var payload = {};

$('input').each(function(){
  var a = $( this ).attr('name');
  var b = $( this ).attr('value');
  payload[a] = b

});
